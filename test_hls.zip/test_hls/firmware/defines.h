#ifndef DEFINES_H_
#define DEFINES_H_

#include "ap_fixed.h"
#include "ap_int.h"
#include "nnet_utils/nnet_types.h"
#include <cstddef>
#include <cstdio>

// hls-fpga-machine-learning insert numbers
#define N_INPUT_1_1 232
#define N_INPUT_2_1 1
#define N_OUTPUTS_2 230
#define N_FILT_2 5
#define N_OUTPUTS_2 230
#define N_FILT_2 5
#define N_OUTPUTS_4 115
#define N_FILT_4 5
#define N_OUTPUTS_5 113
#define N_FILT_5 10
#define N_OUTPUTS_5 113
#define N_FILT_5 10
#define N_OUTPUTS_7 56
#define N_FILT_7 10
#define N_OUTPUTS_8 54
#define N_FILT_8 20
#define N_OUTPUTS_8 54
#define N_FILT_8 20
#define N_OUTPUTS_10 27
#define N_FILT_10 20
#define OUT_WIDTH_11 54
#define N_CHAN_11 20
#define N_OUTPUTS_12 52
#define N_FILT_12 20
#define N_OUTPUTS_12 52
#define N_FILT_12 20
#define OUT_WIDTH_14 104
#define N_CHAN_14 20
#define N_OUTPUTS_15 102
#define N_FILT_15 10
#define N_OUTPUTS_15 102
#define N_FILT_15 10
#define OUT_WIDTH_17 204
#define N_CHAN_17 10
#define N_OUTPUTS_18 202
#define N_FILT_18 5
#define N_OUTPUTS_18 202
#define N_FILT_18 5
#define N_SIZE_0_20 1010
#define N_LAYER_21 232
#define N_LAYER_21 232
#define N_SIZE_0_23 232
#define N_LAYER_21 232
#define N_LAYER_25 232


// hls-fpga-machine-learning insert layer-precision
typedef ap_fixed<16,6> input_t;
typedef ap_fixed<16,6> model_default_t;
typedef ap_fixed<35,15> conv1d_result_t;
typedef ap_fixed<16,6> conv1d_weight_t;
typedef ap_fixed<16,6> conv1d_bias_t;
typedef ap_fixed<16,6> layer3_t;
typedef ap_fixed<18,8> conv1d_relu_table_t;
typedef ap_fixed<16,6> layer4_t;
typedef ap_fixed<37,17> conv1d_1_result_t;
typedef ap_fixed<16,6> conv1d_1_weight_t;
typedef ap_fixed<16,6> conv1d_1_bias_t;
typedef ap_fixed<16,6> layer6_t;
typedef ap_fixed<18,8> conv1d_1_relu_table_t;
typedef ap_fixed<16,6> layer7_t;
typedef ap_fixed<38,18> conv1d_2_result_t;
typedef ap_fixed<16,6> conv1d_2_weight_t;
typedef ap_fixed<16,6> conv1d_2_bias_t;
typedef ap_fixed<16,6> layer9_t;
typedef ap_fixed<18,8> conv1d_2_relu_table_t;
typedef ap_fixed<16,6> layer10_t;
typedef ap_fixed<16,6> layer11_t;
typedef ap_fixed<39,19> conv1d_3_result_t;
typedef ap_fixed<16,6> conv1d_3_weight_t;
typedef ap_fixed<16,6> conv1d_3_bias_t;
typedef ap_fixed<16,6> layer13_t;
typedef ap_fixed<18,8> conv1d_3_relu_table_t;
typedef ap_fixed<16,6> layer14_t;
typedef ap_fixed<39,19> conv1d_4_result_t;
typedef ap_fixed<16,6> conv1d_4_weight_t;
typedef ap_fixed<16,6> conv1d_4_bias_t;
typedef ap_fixed<16,6> layer16_t;
typedef ap_fixed<18,8> conv1d_4_relu_table_t;
typedef ap_fixed<16,6> layer17_t;
typedef ap_fixed<38,18> conv1d_5_result_t;
typedef ap_fixed<16,6> conv1d_5_weight_t;
typedef ap_fixed<16,6> conv1d_5_bias_t;
typedef ap_fixed<16,6> layer19_t;
typedef ap_fixed<18,8> conv1d_5_relu_table_t;
typedef ap_fixed<43,23> dense_result_t;
typedef ap_fixed<16,6> dense_weight_t;
typedef ap_fixed<16,6> dense_bias_t;
typedef ap_uint<1> layer21_index;
typedef ap_fixed<16,6> layer22_t;
typedef ap_fixed<18,8> dense_relu_table_t;
typedef ap_fixed<17,7> add_result_t;
typedef ap_fixed<42,22> result_t;
typedef ap_fixed<16,6> out1_weight_t;
typedef ap_fixed<16,6> out1_bias_t;
typedef ap_uint<1> layer25_index;


#endif
