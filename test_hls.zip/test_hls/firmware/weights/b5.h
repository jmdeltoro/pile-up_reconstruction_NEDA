//Numpy array shape [10]
//Min -0.571519434452
//Max -0.008719163947
//Number of zeros 0

#ifndef B5_H_
#define B5_H_

#ifndef __SYNTHESIS__
conv1d_1_bias_t b5[10];
#else
conv1d_1_bias_t b5[10] = {-0.5521377921, -0.5715194345, -0.5428441167, -0.0087191639, -0.5417242050, -0.5442733765, -0.5554320812, -0.4925583303, -0.5539751053, -0.4435922503};

#endif

#endif
