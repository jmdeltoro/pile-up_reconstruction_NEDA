//Numpy array shape [5]
//Min -0.730116248131
//Max -0.544829428196
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
conv1d_bias_t b2[5];
#else
conv1d_bias_t b2[5] = {-0.5448294282, -0.5533962250, -0.5722523332, -0.7301162481, -0.5500750542};

#endif

#endif
