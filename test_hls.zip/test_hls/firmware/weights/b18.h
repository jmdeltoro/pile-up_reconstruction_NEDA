//Numpy array shape [5]
//Min -0.639595150948
//Max -0.284964114428
//Number of zeros 0

#ifndef B18_H_
#define B18_H_

#ifndef __SYNTHESIS__
conv1d_5_bias_t b18[5];
#else
conv1d_5_bias_t b18[5] = {-0.2849641144, -0.6395951509, -0.5150858164, -0.5270572901, -0.6042673588};

#endif

#endif
