//Numpy array shape [10]
//Min -0.677907764912
//Max 0.801617145538
//Number of zeros 0

#ifndef B15_H_
#define B15_H_

#ifndef __SYNTHESIS__
conv1d_4_bias_t b15[10];
#else
conv1d_4_bias_t b15[10] = {0.8016171455, -0.5743084550, -0.5629436970, -0.6431020498, 0.2804152071, 0.5386433601, -0.6779077649, -0.5287773013, 0.6868005991, -0.5640394688};

#endif

#endif
