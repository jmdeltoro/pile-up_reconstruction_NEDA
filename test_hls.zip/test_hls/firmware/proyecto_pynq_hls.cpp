#include <iostream>

#include "proyecto_pynq_hls.h"
#include "parameters.h"


void proyecto_pynq_hls(
    input_t input_1[N_INPUT_1_1*N_INPUT_2_1],
    result_t layer25_out[N_LAYER_25]
) {

    // hls-fpga-machine-learning insert IO
    #pragma HLS ARRAY_RESHAPE variable=input_1 complete dim=0
    #pragma HLS ARRAY_PARTITION variable=layer25_out complete dim=0
    #pragma HLS INTERFACE ap_vld port=input_1,layer25_out 
    #pragma HLS DATAFLOW

    // hls-fpga-machine-learning insert load weights
#ifndef __SYNTHESIS__
    static bool loaded_weights = false;
    if (!loaded_weights) {
        nnet::load_weights_from_txt<conv1d_weight_t, 15>(w2, "w2.txt");
        nnet::load_weights_from_txt<conv1d_bias_t, 5>(b2, "b2.txt");
        nnet::load_weights_from_txt<conv1d_1_weight_t, 150>(w5, "w5.txt");
        nnet::load_weights_from_txt<conv1d_1_bias_t, 10>(b5, "b5.txt");
        nnet::load_weights_from_txt<conv1d_2_weight_t, 600>(w8, "w8.txt");
        nnet::load_weights_from_txt<conv1d_2_bias_t, 20>(b8, "b8.txt");
        nnet::load_weights_from_txt<conv1d_3_weight_t, 1200>(w12, "w12.txt");
        nnet::load_weights_from_txt<conv1d_3_bias_t, 20>(b12, "b12.txt");
        nnet::load_weights_from_txt<conv1d_4_weight_t, 600>(w15, "w15.txt");
        nnet::load_weights_from_txt<conv1d_4_bias_t, 10>(b15, "b15.txt");
        nnet::load_weights_from_txt<conv1d_5_weight_t, 150>(w18, "w18.txt");
        nnet::load_weights_from_txt<conv1d_5_bias_t, 5>(b18, "b18.txt");
        nnet::load_weights_from_txt<dense_weight_t, 234320>(w21, "w21.txt");
        nnet::load_weights_from_txt<dense_bias_t, 232>(b21, "b21.txt");
        nnet::load_weights_from_txt<out1_weight_t, 53824>(w25, "w25.txt");
        nnet::load_weights_from_txt<out1_bias_t, 232>(b25, "b25.txt");
        loaded_weights = true;    }
#endif
    // ****************************************
    // NETWORK INSTANTIATION
    // ****************************************

    // hls-fpga-machine-learning insert layers

    conv1d_result_t layer2_out[N_OUTPUTS_2*N_FILT_2];
    #pragma HLS ARRAY_PARTITION variable=layer2_out complete dim=0
    nnet::conv_1d_cl<input_t, conv1d_result_t, config2>(input_1, layer2_out, w2, b2); // conv1d

    layer3_t layer3_out[N_OUTPUTS_2*N_FILT_2];
    #pragma HLS ARRAY_PARTITION variable=layer3_out complete dim=0
    nnet::relu<conv1d_result_t, layer3_t, relu_config3>(layer2_out, layer3_out); // conv1d_relu

    layer4_t layer4_out[N_OUTPUTS_4*N_FILT_4];
    #pragma HLS ARRAY_PARTITION variable=layer4_out complete dim=0
    nnet::pooling1d_cl<layer3_t, layer4_t, config4>(layer3_out, layer4_out); // max_pooling1d

    conv1d_1_result_t layer5_out[N_OUTPUTS_5*N_FILT_5];
    #pragma HLS ARRAY_PARTITION variable=layer5_out complete dim=0
    nnet::conv_1d_cl<layer4_t, conv1d_1_result_t, config5>(layer4_out, layer5_out, w5, b5); // conv1d_1

    layer6_t layer6_out[N_OUTPUTS_5*N_FILT_5];
    #pragma HLS ARRAY_PARTITION variable=layer6_out complete dim=0
    nnet::relu<conv1d_1_result_t, layer6_t, relu_config6>(layer5_out, layer6_out); // conv1d_1_relu

    layer7_t layer7_out[N_OUTPUTS_7*N_FILT_7];
    #pragma HLS ARRAY_PARTITION variable=layer7_out complete dim=0
    nnet::pooling1d_cl<layer6_t, layer7_t, config7>(layer6_out, layer7_out); // max_pooling1d_1

    conv1d_2_result_t layer8_out[N_OUTPUTS_8*N_FILT_8];
    #pragma HLS ARRAY_PARTITION variable=layer8_out complete dim=0
    nnet::conv_1d_cl<layer7_t, conv1d_2_result_t, config8>(layer7_out, layer8_out, w8, b8); // conv1d_2

    layer9_t layer9_out[N_OUTPUTS_8*N_FILT_8];
    #pragma HLS ARRAY_PARTITION variable=layer9_out complete dim=0
    nnet::relu<conv1d_2_result_t, layer9_t, relu_config9>(layer8_out, layer9_out); // conv1d_2_relu

    layer10_t layer10_out[N_OUTPUTS_10*N_FILT_10];
    #pragma HLS ARRAY_PARTITION variable=layer10_out complete dim=0
    nnet::pooling1d_cl<layer9_t, layer10_t, config10>(layer9_out, layer10_out); // max_pooling1d_2

    layer11_t layer11_out[OUT_WIDTH_11*N_CHAN_11];
    #pragma HLS ARRAY_PARTITION variable=layer11_out complete dim=0
    nnet::resize_nearest<layer10_t, config11>(layer10_out, layer11_out); // up_sampling1d

    conv1d_3_result_t layer12_out[N_OUTPUTS_12*N_FILT_12];
    #pragma HLS ARRAY_PARTITION variable=layer12_out complete dim=0
    nnet::conv_1d_cl<layer11_t, conv1d_3_result_t, config12>(layer11_out, layer12_out, w12, b12); // conv1d_3

    layer13_t layer13_out[N_OUTPUTS_12*N_FILT_12];
    #pragma HLS ARRAY_PARTITION variable=layer13_out complete dim=0
    nnet::relu<conv1d_3_result_t, layer13_t, relu_config13>(layer12_out, layer13_out); // conv1d_3_relu

    layer14_t layer14_out[OUT_WIDTH_14*N_CHAN_14];
    #pragma HLS ARRAY_PARTITION variable=layer14_out complete dim=0
    nnet::resize_nearest<layer13_t, config14>(layer13_out, layer14_out); // up_sampling1d_1

    conv1d_4_result_t layer15_out[N_OUTPUTS_15*N_FILT_15];
    #pragma HLS ARRAY_PARTITION variable=layer15_out complete dim=0
    nnet::conv_1d_cl<layer14_t, conv1d_4_result_t, config15>(layer14_out, layer15_out, w15, b15); // conv1d_4

    layer16_t layer16_out[N_OUTPUTS_15*N_FILT_15];
    #pragma HLS ARRAY_PARTITION variable=layer16_out complete dim=0
    nnet::relu<conv1d_4_result_t, layer16_t, relu_config16>(layer15_out, layer16_out); // conv1d_4_relu

    layer17_t layer17_out[OUT_WIDTH_17*N_CHAN_17];
    #pragma HLS ARRAY_PARTITION variable=layer17_out complete dim=0
    nnet::resize_nearest<layer16_t, config17>(layer16_out, layer17_out); // up_sampling1d_2

    conv1d_5_result_t layer18_out[N_OUTPUTS_18*N_FILT_18];
    #pragma HLS ARRAY_PARTITION variable=layer18_out complete dim=0
    nnet::conv_1d_cl<layer17_t, conv1d_5_result_t, config18>(layer17_out, layer18_out, w18, b18); // conv1d_5

    layer19_t layer19_out[N_OUTPUTS_18*N_FILT_18];
    #pragma HLS ARRAY_PARTITION variable=layer19_out complete dim=0
    nnet::relu<conv1d_5_result_t, layer19_t, relu_config19>(layer18_out, layer19_out); // conv1d_5_relu

    auto& layer20_out = layer19_out;
    dense_result_t layer21_out[N_LAYER_21];
    #pragma HLS ARRAY_PARTITION variable=layer21_out complete dim=0
    nnet::dense<layer19_t, dense_result_t, config21>(layer20_out, layer21_out, w21, b21); // dense

    layer22_t layer22_out[N_LAYER_21];
    #pragma HLS ARRAY_PARTITION variable=layer22_out complete dim=0
    nnet::relu<dense_result_t, layer22_t, relu_config22>(layer21_out, layer22_out); // dense_relu

    auto& layer23_out = input_1;
    add_result_t layer24_out[N_LAYER_21];
    #pragma HLS ARRAY_PARTITION variable=layer24_out complete dim=0
    nnet::add<layer22_t, input_t, add_result_t, config24>(layer22_out, layer23_out, layer24_out); // add

    nnet::dense<add_result_t, result_t, config25>(layer24_out, layer25_out, w25, b25); // out1

}

